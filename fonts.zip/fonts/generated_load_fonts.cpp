
void LoadFontsFromEmbeddedData()
{
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(include_all_fonts_compressed_data, include_all_fonts_compressed_size, 23.0f);
    strncpy(font_config.Name, "Include All Fonts", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Montserrat-Black_compressed_data, Montserrat-Black_compressed_size, 23.0f);
    strncpy(font_config.Name, "Montserrat-Black", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Montserrat-Bold_compressed_data, Montserrat-Bold_compressed_size, 23.0f);
    strncpy(font_config.Name, "Montserrat-Bold", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Montserrat-Italic_compressed_data, Montserrat-Italic_compressed_size, 23.0f);
    strncpy(font_config.Name, "Montserrat-Italic", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Montserrat-Regular_compressed_data, Montserrat-Regular_compressed_size, 23.0f);
    strncpy(font_config.Name, "Montserrat-Regular", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Oswald-Bold_compressed_data, Oswald-Bold_compressed_size, 23.0f);
    strncpy(font_config.Name, "Oswald-Bold", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Oswald-Regular_compressed_data, Oswald-Regular_compressed_size, 23.0f);
    strncpy(font_config.Name, "Oswald-Regular", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Roboto-Black_compressed_data, Roboto-Black_compressed_size, 23.0f);
    strncpy(font_config.Name, "Roboto-Black", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Roboto-Bold_compressed_data, Roboto-Bold_compressed_size, 23.0f);
    strncpy(font_config.Name, "Roboto-Bold", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Roboto-Italic_compressed_data, Roboto-Italic_compressed_size, 23.0f);
    strncpy(font_config.Name, "Roboto-Italic", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Roboto-Regular_compressed_data, Roboto-Regular_compressed_size, 23.0f);
    strncpy(font_config.Name, "Roboto-Regular", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(RobotoCondensed-Black_compressed_data, RobotoCondensed-Black_compressed_size, 23.0f);
    strncpy(font_config.Name, "Robotocondensed-Black", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(RobotoCondensed-Bold_compressed_data, RobotoCondensed-Bold_compressed_size, 23.0f);
    strncpy(font_config.Name, "Robotocondensed-Bold", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(RobotoCondensed-Italic_compressed_data, RobotoCondensed-Italic_compressed_size, 23.0f);
    strncpy(font_config.Name, "Robotocondensed-Italic", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(RobotoCondensed-Regular_compressed_data, RobotoCondensed-Regular_compressed_size, 23.0f);
    strncpy(font_config.Name, "Robotocondensed-Regular", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Ubuntu-Bold_compressed_data, Ubuntu-Bold_compressed_size, 23.0f);
    strncpy(font_config.Name, "Ubuntu-Bold", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Ubuntu-Italic_compressed_data, Ubuntu-Italic_compressed_size, 23.0f);
    strncpy(font_config.Name, "Ubuntu-Italic", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(Ubuntu-Regular_compressed_data, Ubuntu-Regular_compressed_size, 23.0f);
    strncpy(font_config.Name, "Ubuntu-Regular", sizeof(font_config.Name) - 1);
    font_config.Name[sizeof(font_config.Name) - 1] = '\0'; // Ensure null-termination
}

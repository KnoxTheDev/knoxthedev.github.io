import os

# Path to the fonts directory (use raw string to avoid escape characters)
fonts_dir = r'D:\Yugam Software\imgui\examples\example_glfw_opengl3\fonts'

# Output file for the C++ function
output_file = 'generated_load_fonts.cpp'

# Start the C++ function definition
function_code = """
void LoadFontsFromEmbeddedData()
{
"""

# Iterate over the files in the fonts directory
for file in os.listdir(fonts_dir):
    if file.endswith('.h'):
        # Remove the '.h' extension and use the base name as the symbol name
        font_name = file[:-2]
        
        # Generate the AddFontFromMemoryCompressedTTF call
        function_code += f'    ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF({font_name}_compressed_data, {font_name}_compressed_size, 23.0f);\n'
        
        # Add the strncpy call to set the font name
        function_code += f'    strncpy(font_config.Name, "{font_name.replace("_", " ").title()}", sizeof(font_config.Name) - 1);\n'
        function_code += f'    font_config.Name[sizeof(font_config.Name) - 1] = \'\\0\'; // Ensure null-termination\n'

# Close the C++ function definition
function_code += "}\n"

# Write the generated function code to the output file
with open(output_file, 'w') as f:
    f.write(function_code)

print(f"Generated {output_file} with LoadFontsFromEmbeddedData() function including font name setting.")

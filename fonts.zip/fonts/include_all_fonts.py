import os

# Path to the fonts directory (use raw string to avoid escape characters)
fonts_dir = r'D:\Yugam Software\imgui\examples\example_glfw_opengl3\fonts'

# Output file for including all font headers
output_file = 'include_all_fonts.h'

# Open the output file for writing
with open(output_file, 'w') as f:
    # Write a header comment
    f.write("// Auto-generated file: All font includes\n\n")

    # Iterate over the files in the fonts directory
    for file in os.listdir(fonts_dir):
        if file.endswith('.h'):
            # Write an #include directive for each font header file
            f.write(f'#include "fonts/{file}"\n')

print(f"Generated {output_file} with all font includes.")
